# Online-Retail-Management-System
A website for online shopping with stable backend written in PHP
