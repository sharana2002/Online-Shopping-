<html>
<head>
<title>Product Management</title>
</head>
<body bgcolor="#40C4FF">
<table bgcolor="#0091EA" align="center" style="width:100%" height="20%" >
<!-- <td><img src="http://localhost:8080/myphp/vitlogo.jpg" alt="VIT UNIVERSITY" style="width:250px;height:130px;"></td> -->
<td  width="100%"><h1 align="center">ONLINE RETAIL MANAGEMENT SYSTEM</h1></td>
</table>
<form>
<br>
<br>
<p align="center">
<a href="http://localhost:8080/myphp/productadd.php"><input type="button" value="Add a new product" style="width: 200px; height: 60px" /></a></p>
<p align="center">
<a href="http://localhost:8080/myphp/productmodify.php"><input type="button" value="Modify Product Details" style="width: 200px; height: 60px" /></a></p>
<p align="center">
<a href="http://localhost:8080/myphp/productsearch.php"><input type="button" value="Search a Product" style="width: 200px; height: 60px" /></a></p>
<p align="center">
<a href="http://localhost:8080/myphp/productdelete.php"><input type="button" value="Delete a Product" style="width: 200px; height: 60px" /></a></p>
</form>

</body>
</html>